export class User {
  name: string = '';
  job: string = '';
  picture: string = '';
  keylogin: string = '';
  peronalId: string = '';
  userId: string = '';
  dateBegin: string = '';
  dateEnd: string = '';
  status: string = '';
  land: string = '';
  email: string = '';
  fullName: string = '';
  farmIdPrefered: string = '';
  country_id: string = '';
  token: string = '';
}
