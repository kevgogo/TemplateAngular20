import { Injectable, signal, computed, effect } from '@angular/core';
import {
  LayoutState,
  SidebarMode,
  LayoutToggles,
  LayoutPositions,
  Area,
  Position,
} from '@core/models/layout.models';

const LS_MODE = 'sidebarMode';
const LS_COLL = 'sidebarCollapsed';

// Compat llaves antiguas
const LS_NAV_FIXED = 'navFixed';
const LS_BC_FIXED  = 'breadcrumbFixed';
const LS_PH_FIXED  = 'pageHeaderFixed';

// Posiciones persistidas (nuevo esquema)
const LS_POS_NAV  = 'posNav';
const LS_POS_BC   = 'posBreadcrumbs';
const LS_POS_HEAD = 'posHeadbar';
const LS_POS_SB   = 'posSidebar';

@Injectable({ providedIn: 'root' })
export class LayoutService {
  // --- Estado sidebar ---
  private _state = signal<LayoutState>({
    sidebarMode: (localStorage.getItem(LS_MODE) as SidebarMode) || 'fixed',
    sidebarCollapsed: localStorage.getItem(LS_COLL) === '1',
    floatingOpen: false,
  });
  readonly state = computed(() => this._state());

  setSidebarMode(mode: SidebarMode) {
    this._state.update(s => ({ ...s, sidebarMode: mode }));
    localStorage.setItem(LS_MODE, mode);
  }

  /** Colapsa/expande la sidebar y persiste */
  toggleSidebarCollapsed(force?: boolean) {
    this._state.update(s => {
      const collapsed = typeof force === 'boolean' ? force : !s.sidebarCollapsed;
      localStorage.setItem(LS_COLL, collapsed ? '1' : '0');
      return { ...s, sidebarCollapsed: collapsed };
    });
  }

  setFloatingOpen(open: boolean) {
    this._state.update(s => ({ ...s, floatingOpen: open }));
  }

  // --- Posiciones (fixed/sticky/static) ---
  private readPositions(): LayoutPositions {
    const readPos = (key: string, fallback: Position): Position =>
      (localStorage.getItem(key) as Position) || fallback;

    // Compat desde toggles antiguos
    const compatNavFixed = (localStorage.getItem(LS_NAV_FIXED) ?? '1') === '1';
    const compatBcFixed  = (localStorage.getItem(LS_BC_FIXED)  ?? '1') === '1';
    const compatHdFixed  = (localStorage.getItem(LS_PH_FIXED)  ?? '1') === '1';

    return {
      nav:         readPos(LS_POS_NAV,  compatNavFixed ? 'fixed' : 'static'),
      breadcrumbs: readPos(LS_POS_BC,   compatBcFixed  ? 'fixed' : 'static'),
      headbar:     readPos(LS_POS_HEAD, compatHdFixed  ? 'fixed' : 'static'),
      sidebar:     readPos(LS_POS_SB,   'sticky'),
    };
  }

  private _positions = signal<LayoutPositions>(this.readPositions());
  readonly positions = computed(() => this._positions());

  /** Vista booleana (compat) */
  readonly toggles = computed<LayoutToggles>(() => {
    const p = this._positions();
    return {
      navFixed:         p.nav === 'fixed',
      breadcrumbsFixed: p.breadcrumbs === 'fixed',
      pageHeaderFixed:  p.headbar === 'fixed',
    };
  });

  setPosition(area: Area, pos: Position) {
    this._positions.update(p => {
      const next: LayoutPositions = { ...p, [area]: pos };
      switch (area) {
        case 'nav':         localStorage.setItem(LS_POS_NAV,  pos); break;
        case 'breadcrumbs': localStorage.setItem(LS_POS_BC,   pos); break;
        case 'headbar':     localStorage.setItem(LS_POS_HEAD, pos); break;
        case 'sidebar':     localStorage.setItem(LS_POS_SB,   pos); break;
      }
      return next;
    });
  }

  /** Alterna fijo/estático para nav/breadcrumbs/headbar */
  toggleFixed(area: Exclude<Area, 'sidebar'>, force?: boolean) {
    const current = this._positions()[area];
    const to: Position =
      typeof force === 'boolean'
        ? (force ? 'fixed' : 'static')
        : (current === 'fixed' ? 'static' : 'fixed');

    this.setPosition(area, to);
  }

  /** Alterna fijo/sticky para la sidebar */
  toggleSidebarFixed(force?: boolean) {
    const isFixed = this._positions().sidebar === 'fixed';
    const to: Position =
      typeof force === 'boolean'
        ? (force ? 'fixed' : 'sticky')
        : (isFixed ? 'sticky' : 'fixed');

    this.setPosition('sidebar', to);
  }

  constructor() {
    // Refleja posiciones en clases del <body>
    effect(() => {
      const p = this._positions();
      document.body.classList.toggle('fixed-navbar',      p.nav === 'fixed');
      document.body.classList.toggle('fixed-breadcrumbs', p.breadcrumbs === 'fixed');
      document.body.classList.toggle('fixed-pageheader',  p.headbar === 'fixed');
      document.body.classList.toggle('fixed-sidebar',     p.sidebar === 'fixed');
    });
  }
}
