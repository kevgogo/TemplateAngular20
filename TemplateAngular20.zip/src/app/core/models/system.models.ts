export interface System {
  id_system: number;
  description: string;
  status: string;
  user_create: string;
  user_modify: string;
}
