import {
  Component,
  EventEmitter,
  Output,
  computed,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import {
  ThemeService,
  SKIN_OPTIONS,
  SkinOption,
} from '@core/services/theme.service';
import { LayoutService } from '@core/services/layout.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, BsDropdownModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent {
  @Output() toggleSidebar = new EventEmitter<void>();

  private readonly layout = inject(LayoutService);
  public readonly theme = inject(ThemeService);

  SKINS: SkinOption[] = SKIN_OPTIONS;

  isNavFixed = computed(() => this.layout.toggles().navFixed);
  isBreadcrumbsFixed = computed(() => this.layout.toggles().breadcrumbsFixed);
  isHeaderFixed = computed(() => this.layout.toggles().pageHeaderFixed);
  isSidebarFixed = computed(() => this.layout.positions().sidebar === 'fixed');

  onToggleSidebar() {
    this.layout.toggleSidebarCollapsed();
  }
  onToggleNavFixed() {
    this.layout.toggleFixed('nav');
  }
  onToggleBreadcrumbsFixed() {
    this.layout.toggleFixed('breadcrumbs');
  }
  onToggleHeaderFixed() {
    this.layout.toggleFixed('headbar');
  }
  onToggleSidebarFixed() {
    this.layout.toggleSidebarFixed();
  }

  onToggleTheme() {
    this.theme.toggleTheme();
  }
  onApplySkin(name: SkinOption['name']) {
    this.theme.setSkin(name);
  }
}
