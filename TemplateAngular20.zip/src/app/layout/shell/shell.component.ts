// src/app/layout/shell/shell.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

// ❗️Importa por NOMBRE y desde el archivo del componente
import { NavbarComponent } from '@layout/navbar/navbar.component';
import { SidebarComponent } from '@layout/sidebar/sidebar.component';
import { BreadcrumbsComponent } from '@layout/breadcrumbs/breadcrumbs.component';
import { HeadbarComponent } from '@layout/headbar/headbar.component';

// Si usas módulos de terceros (NgModules) como ngx-bootstrap, también se permiten aquí:
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet, // standalone
    NavbarComponent, // ✅ standalone
    SidebarComponent,
    BreadcrumbsComponent,
    HeadbarComponent,
    BsDropdownModule, // ✅ NgModule permitido en imports
  ],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
})
export class ShellComponent {
  onToggleSidebar() {
    // lógica para mostrar/ocultar sidebar
  }
  collapsed() {
    return false; // lógica para determinar si el sidebar está colapsado
  }
}
