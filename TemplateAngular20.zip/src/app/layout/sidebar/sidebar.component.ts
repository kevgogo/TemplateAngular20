// sidebar.component.ts
import { Component, Input } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  host: { '[class.collapsed]': 'collapsed' },
})
export class SidebarComponent {
  @Input() collapsed = false;
  items = [
    { icon: 'bi-house', label: 'Inicio', link: '/' },
    { icon: 'bi-grid', label: 'Módulos', link: '/modules' },
  ];
}
