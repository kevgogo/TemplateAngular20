import { CommonModule } from '@angular/common';
import { Component, HostBinding, Input } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

export type NavItem = {
  icon?: string;
  label: string;
  link?: string;
  children?: NavItem[];
};

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, BsDropdownModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent {
  @Input() collapsed = false;

  // Ejemplo basado en tu captura. Cambia rutas/etiquetas según tu app.
  items: NavItem[] = [
    { icon: 'bi-house', label: 'Inicio', link: '/' },

    {
      icon: 'bi-grid',
      label: 'Módulos',
      link: '/modules',
      children: [
        {
          icon: 'bi-basket',
          label: 'Ventas',
          link: '/modules/sales',
          children: [
            {
              icon: 'bi-bag-plus',
              label: 'Pedidos',
              link: '/modules/sales/orders',
              children: [
                {
                  icon: 'bi-plus-circle',
                  label: 'Nuevo',
                  link: '/modules/sales/orders/new',
                },
                {
                  icon: 'bi-search',
                  label: 'Buscar',
                  link: '/modules/sales/orders/search',
                },
                {
                  icon: 'bi-diagram-3',
                  label: 'Flujos',
                  link: '/modules/sales/orders/flows',
                  children: [
                    {
                      icon: 'bi-gear',
                      label: 'Aprobaciones',
                      link: '/modules/sales/orders/flows/approvals',
                      children: [
                        {
                          icon: 'bi-sliders',
                          label: 'Reglas avanzadas',
                          link: '/modules/sales/orders/flows/approvals/advanced-rules',
                        },
                      ],
                    },
                  ],
                },
              ],
            },
            {
              icon: 'bi-people',
              label: 'Clientes',
              link: '/modules/sales/customers',
            },
            {
              icon: 'bi-receipt',
              label: 'Facturación',
              link: '/modules/sales/invoicing',
            },
          ],
        },

        {
          icon: 'bi-truck',
          label: 'Logística',
          link: '/modules/logistics',
          children: [
            {
              icon: 'bi-box-seam',
              label: 'Inventario',
              link: '/modules/logistics/inventory',
              children: [
                {
                  icon: 'bi-arrow-left-right',
                  label: 'Movimientos',
                  link: '/modules/logistics/inventory/movements',
                },
                {
                  icon: 'bi-upc-scan',
                  label: 'Lotes',
                  link: '/modules/logistics/inventory/batches',
                  children: [
                    {
                      icon: 'bi-qr-code',
                      label: 'Series',
                      link: '/modules/logistics/inventory/batches/series',
                    },
                  ],
                },
              ],
            },
            {
              icon: 'bi-pin-map',
              label: 'Rutas',
              link: '/modules/logistics/routes',
            },
            {
              icon: 'bi-clipboard2-check',
              label: 'Despachos',
              link: '/modules/logistics/shipments',
            },
          ],
        },

        {
          icon: 'bi-graph-up',
          label: 'Analítica',
          link: '/modules/analytics',
          children: [
            {
              icon: 'bi-speedometer',
              label: 'Dashboards',
              link: '/modules/analytics/dashboards',
            },
            {
              icon: 'bi-kanban',
              label: 'KPIs',
              link: '/modules/analytics/kpis',
              children: [
                {
                  icon: 'bi-calendar-week',
                  label: 'Semanal',
                  link: '/modules/analytics/kpis/weekly',
                },
                {
                  icon: 'bi-calendar3',
                  label: 'Mensual',
                  link: '/modules/analytics/kpis/monthly',
                  children: [
                    {
                      icon: 'bi-trophy',
                      label: 'Top 10',
                      link: '/modules/analytics/kpis/monthly/top10',
                    },
                  ],
                },
              ],
            },
            {
              icon: 'bi-file-earmark-bar-graph',
              label: 'Reportes',
              link: '/modules/analytics/reports',
            },
          ],
        },
      ],
    },

    {
      icon: 'bi-sliders2-vertical',
      label: 'Configuración',
      link: '/settings',
      children: [
        {
          icon: 'bi-people',
          label: 'Usuarios',
          link: '/settings/users',
          children: [
            {
              icon: 'bi-person-gear',
              label: 'Roles',
              link: '/settings/users/roles',
              children: [
                {
                  icon: 'bi-shield-lock',
                  label: 'Permisos',
                  link: '/settings/users/roles/permissions',
                  children: [
                    {
                      icon: 'bi-terminal',
                      label: 'Condiciones',
                      link: '/settings/users/roles/permissions/conditions',
                    },
                  ],
                },
              ],
            },
            {
              icon: 'bi-person-check',
              label: 'Perfiles',
              link: '/settings/users/profiles',
            },
          ],
        },
        { icon: 'bi-palette', label: 'Temas', link: '/settings/themes' },
        {
          icon: 'bi-plug',
          label: 'Integraciones',
          link: '/settings/integrations',
          children: [
            {
              icon: 'bi-cloud',
              label: 'Almacenamiento',
              link: '/settings/integrations/storage',
            },
            {
              icon: 'bi-credit-card',
              label: 'Pagos',
              link: '/settings/integrations/payments',
            },
          ],
        },
      ],
    },

    {
      icon: 'bi-info-circle',
      label: 'Ayuda',
      link: '/help',
      children: [
        { icon: 'bi-book', label: 'Documentación', link: '/help/docs' },
        { icon: 'bi-life-preserver', label: 'Soporte', link: '/help/support' },
        { icon: 'bi-bug', label: 'Reportar un problema', link: '/help/report' },
      ],
    },

    {
      icon: 'bi-box-arrow-up-right',
      label: 'Web corporativa',
      link: 'https://empresa.com',
    },
  ];
  @HostBinding('class.is-collapsed') get hostCollapsed() {
    return this.collapsed;
  }

  /** ids jerárquicos para controlar aperturas */
  private open = new Set<string>();
  nodeId(parentId: string | null, idx: number) {
    return parentId ? `${parentId}.${idx}` : `${idx}`;
  }
  isOpen(id: string) {
    return this.open.has(id);
  }
  toggle(id: string) {
    if (this.collapsed) return; // solo inline cuando expandido
    this.open.has(id) ? this.open.delete(id) : this.open.add(id);
  }

  /** evitar navegación cuando el item tiene hijos (primer nivel y anidados) */
  onItemClick(ev: MouseEvent, node: NavItem, id: string) {
    if (node.children?.length) {
      ev.preventDefault();
      ev.stopPropagation();
      this.toggle(id);
    }
  }

  /** flyout para colapsado (hover en primer nivel) */
  hoverIndex: number | null = null;
  onEnter(i: number, hasChildren: boolean) {
    if (this.collapsed && hasChildren) this.hoverIndex = i;
  }
  onLeave(i: number) {
    if (this.hoverIndex === i) this.hoverIndex = null;
  }
}
